#!/bin/csh
./mergehex -m ../../nRF_SDK_13_0_0/components/softdevice/s140/hex/s140_nrf52840_5.0.0-2.alpha_softdevice.hex _build/nrf52840_xxaa.hex -o _build/nrf52840_xxaa.hex 
