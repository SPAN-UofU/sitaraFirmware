#!/bin/csh
make 
./merge.sh
make flash
